**Web ini bersifat statis dan tidak dapat melakukan banyak perubahan pada admin panel.**

## Note:

**Silahkan melakukan perintah berikut untuk menjalankan aplikasi:**
- `composer install`
- `Masukkan file sql ke database`
- `npm run dev`
- `php artisan serve`

## Username & Password Login:

### Login admin:

- Username: superuser@ifest.uajy.ac.id
- Password: superuser

### Login admin:

- Username: sekretariat@ifest.uajy.ac.id
- Password: superuser