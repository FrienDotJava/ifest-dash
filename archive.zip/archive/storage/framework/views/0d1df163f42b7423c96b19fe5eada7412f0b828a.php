<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.layouts.defaultlayout','data' => []]); ?>
<?php $component->withName('layouts.defaultlayout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div id="ifst-app" class="app-wrapper" style="height: 100vh">

        <div class="app-overlay"></div>

        <!-- Pageloader -->
        <div class="pageloader is-full"></div>
        <div class="infraloader is-full is-active"></div>

                    <div class="page-content-inner">

                        <!--Confirm Account-->
                        <div class="confirm-account-wrapper mt-5">
                            <div class="wrapper-inner">
                                <div class="action-box">
                                    <div class="box-content">
                                        <h3 class="dark-inverted">Verifikasi email anda</h3>
                                        <p><?php echo e(__('Terima kasih telah mendaftar! Sebelum memulai, dapatkah Anda memverifikasi alamat email Anda dengan mengklik tautan yang baru saja kami kirimkan melalui email kepada Anda? Jika Anda tidak menerima email tersebut, kami akan dengan senang hati mengirimkan email lain kepada Anda. ')); ?><br>

                                        <?php if(session('status') == 'verification-link-sent'): ?>
                                            <div class="mt-2 mb-5 font-medium text-sm is-green">
                                                <?php echo e(__('Tautan verifikasi baru telah dikirim ke alamat email yang Anda berikan saat pendaftaran.')); ?>

                                            </div>
                                        <?php endif; ?>

                                        <form class="mt-5" method="POST" action="<?php echo e(route('verification.send')); ?>">
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" class="button h-button is-primary is-raised"><?php echo e(__('Klik disini untuk mengirim ulang')); ?></button>.
                                        </form>
                                        <form class="mt-2" method="POST" action="<?php echo e(route('logout')); ?>">
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" class="button h-button is-danger is-raised"><?php echo e(__('Keluar')); ?></button>.
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>

                </div>
            </div>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php /**PATH C:\Users\FRENDY\Projects\Web Projects\Html Code\ifest-dash\resources\views/auth/verify-email.blade.php ENDPATH**/ ?>