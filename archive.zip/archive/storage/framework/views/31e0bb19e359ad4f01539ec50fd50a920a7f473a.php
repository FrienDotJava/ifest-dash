<?php echo e($slot); ?>

<?php /**PATH C:\Users\FRENDY\Projects\Web Projects\Html Code\ifest-dash\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>