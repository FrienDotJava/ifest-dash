<?php $__env->startSection('title', 'Donor Darah'); ?>
<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.layouts.app','data' => []]); ?>
<?php $component->withName('layouts.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <form action="<?php echo e(route('logout')); ?>" method="post" class="is-hidden" id="logout"><?php echo csrf_field(); ?></form>
    <div id="ifst-app" class="app-wrapper">

        <div class="app-overlay"></div>
        <!-- Pageloader -->
        <div class="pageloader"></div>
        <div class="infraloader is-active"></div>
        <?php echo $__env->make('admin_/slice_/sidehead', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="view-wrapper" data-naver-offset="405" data-menu-item="#dcr-sidebar-menu" data-mobile-item="#dcr-sidebar-menu-mobile">

            <div class="page-content-wrapper">
                <div class="page-content is-relative">

                    <div class="page-title has-text-centered">

                        <div class="title-wrap">
                            <h1 class="title is-4">Donor Darah</h1>
                        </div>

                        <div class="toolbar ml-auto">

                            <div class="toolbar-link">
                                <label class="dark-mode ml-auto">
                                    <input type="checkbox" checked>
                                    <span></span>
                                </label>
                            </div>

                            <?php if(Auth::user()->user_type == 'superuser'): ?>
                            <a class="toolbar-link right-panel-trigger" data-panel="activity-panel">
                                <i data-feather="grid"></i>
                            </a>
                            <?php endif; ?>

                            <div class="toolbar-notifications is-hidden-mobile">
                                <div class="dropdown is-spaced is-dots is-right dropdown-trigger">
                                    <div class="is-trigger" aria-haspopup="true">
                                        <i data-feather="bell"></i>
                                        <?php if(count($notification) > 0): ?>
                                        <span class="new-indicator pulsate"></span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="dropdown-menu" role="menu">
                                        <div class="dropdown-content">
                                            <div class="heading">
                                                <div class="heading-left">
                                                    <h6 class="heading-title">Notifikasi</h6>
                                                </div>
                                            </div>
                                            <ul class="notification-list">
                                                <?php $__currentLoopData = $notification; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notif): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li>
                                                    <a class="notification-item" href="<?php echo e(env('APP_URL')); ?>/su_admin/<?php echo e($notif->id_event); ?>/team/<?php echo e($notif->id_team); ?>">
                                                        <div class="img-left">
                                                            <img class="user-photo" alt="" src="https://via.placeholder.com/150x150" data-demo-src="<?php echo e(asset('storage/'.$notif->event->image_event)); ?>"/>
                                                        </div>
                                                        <div class="user-content">
                                                            <p class="user-info"><span class="name"><?php echo e($notif->team->team_name); ?></span> <?php echo e($notif->message); ?></p>
                                                            <p class="time">
                                                                <time class="is-relative"><?php echo e($notif->created_at->diffForHumans()); ?></time>
                                                            </p>
                                                        </div>
                                                    </a>
                                                </li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php if(count($notification) == 0): ?>
                                                    <li>
                                                        <div class="user-content">
                                                            <p class="user-info">Tidak ada notifikasi</p>
                                                        </div>
                                                    </li>
                                                <?php endif; ?>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="columns">
                        <div class="column is-12">
                            <div class="buttons">
                                <a class="button is-primary is-rounded is-elevated" id="user_num_btn1" href="<?php echo e(env('APP_URL')); ?>/su_admin/donor_darah/export">
                                    <span class="icon">
                                        <i data-feather="download"></i>
                                    </span>
                                    <span>Export Data Donor Darah</span>
                                </a>
                            </div>


                            <div class="flex-table-wrapper">
                                <table class="ui celled table" id="table">
                                    <thead>
                                        <tr>
                                            <th class="has-text-centered">No</th>
                                            <th class="has-text-centered">Nama</th>
                                            <th class="has-text-centered">Email</th>
                                            <th class="has-text-centered">No. Telp</th>
                                            <th class="has-text-centered">Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $donor_darah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="has-text-centered"><?php echo e($loop->iteration); ?></td>
                                            <td class="has-text-centered"><?php echo e($d->nama); ?></td>
                                            <td class="has-text-centered"><?php echo e($d->email); ?></td>
                                            <td class="has-text-centered"><?php echo e($d->no_hp); ?></td>
                                            <td class="has-text-centered">
                                                <a class="button is-info is-rounded is-elevated" id="user_num_btn1" href="<?php echo e(env('APP_URL')); ?>/su_admin/donor_darah/detail/<?php echo e($d->id); ?>">
                                                    <span class="icon">
                                                        <i data-feather="eye"></i>
                                                    </span>
                                                    <span>Detail</span>
                                                </a>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </table>
                            </div>
                        </div>

                    </div>

                </div>
            </div>
        </div>
    </div>
    
    <style>
        .ui.celled.table tbody tr td {
            color: #000000BC;
        }
    </style>


    <!-- addons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fomantic-ui/2.8.8/semantic.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.1/css/dataTables.semanticui.min.css">
    <script src="//cdn.datatables.net/1.13.1/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.1/js/dataTables.semanticui.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/fomantic-ui/2.8.8/semantic.min.js"></script>
    <script>
        $(document).ready(function () {
            $('#table').DataTable(
                {
                    "pagingType": "full_numbers",
                    "lengthMenu": [
                        [10, 25, 50, -1],
                        [10, 25, 50, "All"]
                    ],
                    "responsive": true,
                    "searching": true,
                    "search": {
                        "search": "",
                        "smart": true,
                        "regex": false,
                        "caseInsensitive": true
                    },
                    "language": {
                        "search": "_INPUT_",
                        "searchPlaceholder": "Cari",
                    },
                    
                }
            );
            $('.dataTables_filter').find('span').removeClass('ui input');
        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?><?php /**PATH C:\Users\FRENDY\Projects\Web Projects\Html Code\ifest-dash\resources\views/admin_/dcr/index.blade.php ENDPATH**/ ?>