<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <title>Informatics Festival #12</title>
        <!-- <link rel="stylesheet" href="<?php echo e(asset('landingpage_/css/bootstrap.min.css')); ?>"> -->
        <!-- <link rel="stylesheet" href="<?php echo e(asset('landingpage_/css/custom.css')); ?>"> -->
        <link rel="stylesheet" href="<?php echo e(asset('landingpage_/css/app.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('landingpage_/css/main.css')); ?>">
        <script src="<?php echo e(asset('landingpage_/js/app.js')); ?>"></script>
        <link rel="shortcut icon" href="<?php echo e(asset('images/ifest.png')); ?>" type="image/x-icon">
        <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
    </head>
    <body id="main_log_fst">
        <?php echo e($slot); ?>

        <!-- <script src="<?php echo e(asset('landingpage_/js/bootstrap.bundle.min.js')); ?>"></script> -->
        <!-- <script src="<?php echo e(asset('landingpage_/js/jquery.min.js')); ?>"></script> -->
        <script src="<?php echo e(asset('landingpage_/js/functions.js')); ?>"></script>
        <script src="<?php echo e(asset('landingpage_/js/auth.js')); ?>"></script>
    </body>
</html><?php /**PATH C:\Users\FRENDY\Projects\Web Projects\Html Code\ifest-dash\resources\views/components/layouts/defaultlayout.blade.php ENDPATH**/ ?>