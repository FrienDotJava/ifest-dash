<?php $__env->startComponent('mail::message'); ?>
# Selamat Tim Kamu Sudah Di Verifikasi

Tim kamu sudah di verifikasi oleh panitia, silahkan login ke akun kamu untuk melihat detail tim kamu dan mengupload task yang baru.

<?php $__env->startComponent('mail::button', ['url' => config('app.url').'/masuk']); ?>
Login
<?php echo $__env->renderComponent(); ?>

Terima Kasih,<br>
<?php echo e(__('Informatics Festival #11')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\Users\FRENDY\Projects\Web Projects\Html Code\ifest-dash\resources\views/emails/verifications.blade.php ENDPATH**/ ?>