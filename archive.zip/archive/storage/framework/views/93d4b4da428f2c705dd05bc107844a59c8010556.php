<?php $__env->startSection('title', 'Profil'); ?>
<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.layouts.app','data' => []]); ?>
<?php $component->withName('layouts.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <form action="<?php echo e(route('logout')); ?>" method="post" class="is-hidden" id="logout"><?php echo csrf_field(); ?></form>
    <div id="ifst-app" class="app-wrapper">

        <div class="app-overlay"></div>
        <!-- Pageloader -->
        <div class="pageloader"></div>
        <div class="infraloader is-active"></div>
        <?php echo $__env->make('admin_/slice_/sidehead', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="view-wrapper">

            <div class="page-content-wrapper">
                <div class="page-content is-relative">

                    <div class="page-title has-text-centered">

                        <div class="title-wrap">
                            <h1 class="title is-4">Profil</h1>
                        </div>

                        <div class="toolbar ml-auto">

                            <div class="toolbar-link">
                                <label class="dark-mode ml-auto">
                                    <input type="checkbox" checked>
                                    <span></span>
                                </label>
                            </div>

                            <?php if(Auth::user()->user_type == 'superuser'): ?>
                            <a class="toolbar-link right-panel-trigger" data-panel="activity-panel">
                                <i data-feather="grid"></i>
                            </a>
                            <?php endif; ?>

                            <div class="toolbar-notifications is-hidden-mobile">
                                <div class="dropdown is-spaced is-dots is-right dropdown-trigger">
                                    <div class="is-trigger" aria-haspopup="true">
                                        <i data-feather="bell"></i>
                                        <?php if(count($notification) > 0): ?>
                                        <span class="new-indicator pulsate"></span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="dropdown-menu" role="menu">
                                        <div class="dropdown-content">
                                            <div class="heading">
                                                <div class="heading-left">
                                                    <h6 class="heading-title">Notifikasi</h6>
                                                </div>
                                                <!-- <div class="heading-right">
                                                    <a class="notification-link" href="admin-profile-notifications.html">See all</a>
                                                </div> -->
                                            </div>
                                            <ul class="notification-list">
                                                <?php $__currentLoopData = $notification; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notif): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li>
                                                    <a class="notification-item" href="<?php echo e(env('APP_URL')); ?>/su_admin/<?php echo e($notif->id_event); ?>/team/<?php echo e($notif->id_team); ?>">
                                                        <div class="img-left">
                                                            <img class="user-photo" alt="" src="https://via.placeholder.com/150x150" data-demo-src="<?php echo e(asset('storage/'.$notif->event->image_event)); ?>"/>
                                                        </div>
                                                        <div class="user-content">
                                                            <p class="user-info"><span class="name"><?php echo e($notif->team->team_name); ?></span> <?php echo e($notif->message); ?></p>
                                                            <p class="time">
                                                                <time class="is-relative"><?php echo e($notif->created_at->diffForHumans()); ?></time>
                                                            </p>
                                                        </div>
                                                    </a>
                                                </li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php if(count($notification) == 0): ?>
                                                    <li>
                                                        <div class="user-content">
                                                            <p class="user-info">Tidak ada notifikasi</p>
                                                        </div>
                                                    </li>
                                                <?php endif; ?>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="account-wrapper">
                        <div class="columns">

                            <!--Navigation-->
                            <div class="column is-4">
                                <div class="account-box is-navigation">
                                    <div class="media-flex-center">
                                        <div class="h-avatar is-large">
                                            <img class="avatar" src="https://via.placeholder.com/150x150"
                                                data-demo-src="<?php echo e(asset('storage/'.Auth::user()->foto)); ?>" alt="">
                                        </div>
                                        <div class="flex-meta">
                                            <span><?php echo e(Auth::user()->fullname); ?></span>
                                            <span><?php echo e(Auth::user()->user_type); ?></span>
                                        </div>
                                    </div>
                                    <div class="account-menu">
                                        <a onclick="personal_info()" class="account-menu-item personal-info is-active">
                                            <i class="lnil lnil-user-alt"></i>
                                            <span>Informasi Akun</span>
                                            <span class="end">
                                                <i class="fas fa-arrow-right"></i>
                                            </span>
                                        </a>
                                        <a onclick="change_password()" class="account-menu-item change_password">
                                            <i class="lnil lnil-key-alt"></i>
                                            <span>Ganti password</span>
                                            <span class="end">
                                                <i class="fas fa-arrow-right"></i>
                                            </span>
                                        </a>
                                    </div>
                                </div>
                            </div>

                            <div class="column is-8" id="personal-info">
                                <div class="account-box is-form is-footerless">
                                    <div class="form-head stuck-header">
                                        <div class="form-head-inner">
                                            <div class="left">
                                                <h3>Informasi Akun</h3>
                                            </div>
                                            <div class="right is-hidden-mobile">
                                                <div class="buttons">
                                                    <a onclick="edit_profil()" class="button h-button is-primary is-raised">Ubah Profil</a>
                                                </div>
                                            </div>
                                            <a onclick="edit_profil()" class="button h-button is-primary is-raised is-hidden-desktop is-hidden-tablet" style="width: 100%!important">Ubah Profil</a>
                                        </div>
                                    </div>
                                    <div class="form-body">
                                        <!--Fieldset-->
                                        <div class="fieldset">
                                            <div class="fieldset-heading">
                                                <h4>Informasi Personal</h4>
                                                <p>Data personal anda.</p>
                                            </div>

                                            <div class="columns is-multiline">
                                                <!--Field-->
                                                <div class="column is-12">
                                                    <div class="field">
                                                        <label>Nama Lengkap</label>
                                                        <div class="control has-icon">
                                                            <input type="text" class="input" value="<?php echo e(Auth::user()->fullname); ?>" disabled>
                                                            <div class="form-icon">
                                                                <i data-feather="user"></i>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!--Field-->
                                                <div class="column is-12">
                                                    <div class="field">
                                                        <label>Email</label>
                                                        <div class="control has-icon">
                                                            <input type="text" class="input" value="<?php echo e(Auth::user()->email); ?>" disabled>
                                                            <div class="form-icon">
                                                                <i data-feather="mail"></i>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!--Field-->
                                                <div class="column is-12">
                                                    <div class="field">
                                                        <label>Nomor Telpon</label>
                                                        <div class="control has-icon">
                                                            <input type="text" class="input" value="<?php echo e(Auth::user()->no_telpon); ?>" disabled>
                                                            <div class="form-icon">
                                                                <i data-feather="phone"></i>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!--Field-->
                                                <div class="column is-12">
                                                    <div class="field">
                                                        <label>ID Line</label>
                                                        <div class="control has-icon">
                                                            <input type="text" class="input" value="<?php echo e(Auth::user()->id_line); ?>" disabled>
                                                            <div class="form-icon">
                                                                <i data-feather="smartphone"></i>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="column is-8" id="change-password">
                                <form method="post" action="<?php echo e(env('APP_URL')); ?>/su_admin/change_password"class="account-box is-form is-footerless">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PATCH'); ?>
                                    <div class="form-head stuck-header">
                                        <div class="form-head-inner">
                                            <div class="left">
                                                <h3>Ganti Password</h3>
                                            </div>
                                            <div class="right is-hidden-mobile">
                                                <div class="buttons">
                                                    <button class="button h-button is-primary is-raised">Perbarui Password</button>
                                                </div>
                                            </div>
                                            <button class="button h-button is-primary is-raised is-hidden-desktop is-hidden-tablet" style="width: 100%!important">Perbarui Password</button>
                                        </div>
                                    </div>
                                    <div class="form-body">
                                        <!--Fieldset-->
                                        <div class="fieldset">
                                            <div class="fieldset-heading">
                                                <h4>Perbarui Password</h4>
                                                <p>Ubah password untuk meningkatkan keamanan akun anda.</p>
                                            </div>

                                            <div class="columns is-multiline">
                                                <!--Field-->
                                                <div class="column is-12">
                                                    <div class="field">
                                                        <label>Password Sekarang</label>
                                                        <div class="control has-icon">
                                                            <input type="password" class="input <?php $__errorArgs = ['current_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="current_password" required>
                                                            <div class="form-icon">
                                                                <i data-feather="key"></i>
                                                            </div>
                                                        </div>
                                                        <?php $__errorArgs = ['current_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <div class="danger-text"><?php echo e($message); ?></div>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div>
                                                <!--Field-->
                                                <div class="column is-12">
                                                    <div class="field">
                                                        <label>Password Baru</label>
                                                        <div class="control has-icon">
                                                            <input type="password" name="new_password" class="input <?php $__errorArgs = ['new_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" autocomplete="new-password" required>
                                                            <div class="form-icon">
                                                                <i data-feather="key"></i>
                                                            </div>
                                                        </div>
                                                        <?php $__errorArgs = ['new_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <div class="danger-text"><?php echo e($message); ?></div>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div>
                                                <!--Field-->
                                                <div class="column is-12">
                                                    <div class="field">
                                                        <label>Konfirmasi Password</label>
                                                        <div class="control has-icon">
                                                            <input type="password" class="input" name="new_password_confirmation" required autocomplete="new-password">
                                                            <div class="form-icon">
                                                                <i data-feather="repeat"></i>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </form>
                            </div>

                            <div class="column is-8" id="edit-profil">
                                <form class="account-box is-form is-footerless" action="<?php echo e(env('APP_URL')); ?>/su_admin/edit_profil" method="POST" enctype="multipart/form-data">
                                    <div class="form-head stuck-header">
                                        <div class="form-head-inner">
                                            <div class="left">
                                                <h3>Informasi Akun</h3>
                                            </div>
                                            <div class="right">
                                                <div class="buttons">
                                                    <a onclick="personal_info()" class="button h-button is-light is-dark-outlined">
                                                        <span class="icon">
                                                            <i class="lnir lnir-arrow-left rem-100"></i>
                                                        </span>
                                                        <span>Kembali</span>
                                                    </a>
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('PATCH'); ?>
                                                    <button type="submit" class="button h-button is-primary is-raised">Perbarui</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-body">
                                        <!--Fieldset-->
                                        <div class="fieldset">
                                            <div class="fieldset-heading">
                                                <h4>Informasi Personal</h4>
                                                <p>Data personal anda.</p>
                                            </div>

                                            <div class="columns is-multiline">
                                                <!--Field-->
                                                <div class="column is-12">
                                                    <div class="field">
                                                        <label>Nama Lengkap</label>
                                                        <div class="control has-icon">
                                                            <input type="text" name="fullname" class="input <?php $__errorArgs = ['fullname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(Auth::user()->fullname); ?>" required>
                                                            <div class="form-icon">
                                                                <i data-feather="user"></i>
                                                            </div>
                                                        </div>
                                                        <?php $__errorArgs = ['fullname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <div class="danger-text">Nama lengkap wajib diisi!</div>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div>
                                                <!--Field-->
                                                <div class="column is-12">
                                                    <div class="field">
                                                        <label>Email</label>
                                                        <div class="control has-icon">
                                                            <input type="text" class="input" value="<?php echo e(Auth::user()->email); ?>" readonly disabled>
                                                            <div class="form-icon">
                                                                <i data-feather="mail"></i>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!--Field-->
                                                <div class="column is-12">
                                                    <div class="field">
                                                        <label>Nomor Telpon</label>
                                                        <div class="control has-icon">
                                                            <input type="number" name="no_telpon" class="input <?php $__errorArgs = ['no_telpon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(Auth::user()->no_telpon); ?>" required>
                                                            <div class="form-icon">
                                                                <i data-feather="phone"></i>
                                                            </div>
                                                        </div>
                                                        <?php $__errorArgs = ['no_telpon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <div class="danger-text">Nomor Telpon wajib diisi!</div>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div>
                                                <!--Field-->
                                                <div class="column is-12">
                                                    <div class="field">
                                                        <label>ID Line</label>
                                                        <div class="control has-icon">
                                                            <input type="text" name="id_line" class="input <?php $__errorArgs = ['id_line'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(Auth::user()->id_line); ?>" required>
                                                            <div class="form-icon">
                                                                <i data-feather="smartphone"></i>
                                                            </div>
                                                        </div>
                                                        <?php $__errorArgs = ['id_line'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <div class="danger-text">ID Line wajib diisi!</div>
                                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>

                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
    <script>
        $('#edit-profil').hide();
        $('#change-password').hide();
        function edit_profil(){
            $('#personal-info').hide();
            $('.personal-info').removeClass('is-active');
            $('.change_password').removeClass('is-active');
            $('#edit-profil').fadeIn('fast');
        }
        function personal_info(){
            $('#edit-profil').hide();
            $('#change-password').hide();
            $('.personal-info').addClass('is-active');
            $('.change_password').removeClass('is-active');
            $('#personal-info').fadeIn('fast');
        }
        function change_password(){
            $('#edit-profil').hide();
            $('#personal-info').hide();
            $('.personal-info').removeClass('is-active');
            $('.change_password').addClass('is-active');
            $('#change-password').fadeIn('fast');
        }
    </script>

    <?php if(session('notif')): ?>
        <script>
            $(document).ready(function () {
                //Notyf Toasts Configuration
                notyf = new Notyf({
                    duration: 3000,
                    position: {
                    x: 'right',
                    y: 'bottom'
                    },
                    types: [{
                    type: 'green',
                    background: themeColors.green,
                    icon: {
                        className: 'fas fa-check',
                        tagName: 'i',
                        text: ''
                    }
                    }]
                }); //Notyf Toasts Demos
                notyf.success("<?php echo e(session('notif')); ?>");
            });
        </script>
    <?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?><?php /**PATH C:\Users\FRENDY\Projects\Web Projects\Html Code\ifest-dash\resources\views/admin_/profil/index.blade.php ENDPATH**/ ?>