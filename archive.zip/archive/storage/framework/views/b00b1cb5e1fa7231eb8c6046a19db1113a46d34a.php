<?php $__env->startSection('title', 'Users'); ?>
<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.layouts.app','data' => []]); ?>
<?php $component->withName('layouts.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <form action="<?php echo e(route('logout')); ?>" method="post" class="is-hidden" id="logout"><?php echo csrf_field(); ?></form>
    <div id="ifst-app" class="app-wrapper">

        <div class="app-overlay"></div>
        <!-- Pageloader -->
        <div class="pageloader"></div>
        <div class="infraloader is-active"></div>
        <?php echo $__env->make('admin_/slice_/sidehead', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="view-wrapper" data-naver-offset="465" data-menu-item="#users-sidebar-menu" data-mobile-item="#users-sidebar-menu-mobile">

            <div class="page-content-wrapper">
                <div class="page-content is-relative">

                    <div class="page-title has-text-centered">

                        <div class="title-wrap">
                            <h1 class="title is-4">Users</h1>
                        </div>

                        <div class="toolbar ml-auto">

                            <div class="toolbar-link">
                                <label class="dark-mode ml-auto">
                                    <input type="checkbox" checked>
                                    <span></span>
                                </label>
                            </div>

                            <?php if(Auth::user()->user_type == 'superuser'): ?>
                            <a class="toolbar-link right-panel-trigger" data-panel="activity-panel">
                                <i data-feather="grid"></i>
                            </a>
                            <?php endif; ?>

                            <div class="toolbar-notifications is-hidden-mobile">
                                <div class="dropdown is-spaced is-dots is-right dropdown-trigger">
                                    <div class="is-trigger" aria-haspopup="true">
                                        <i data-feather="bell"></i>
                                        <?php if(count($notification) > 0): ?>
                                        <span class="new-indicator pulsate"></span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="dropdown-menu" role="menu">
                                        <div class="dropdown-content">
                                            <div class="heading">
                                                <div class="heading-left">
                                                    <h6 class="heading-title">Notifikasi</h6>
                                                </div>
                                                <!-- <div class="heading-right">
                                                    <a class="notification-link" href="admin-profile-notifications.html">See all</a>
                                                </div> -->
                                            </div>
                                            <ul class="notification-list">
                                                <?php $__currentLoopData = $notification; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notif): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li>
                                                    <a class="notification-item" href="<?php echo e(env('APP_URL')); ?>/su_admin/<?php echo e($notif->id_event); ?>/team/<?php echo e($notif->id_team); ?>">
                                                        <div class="img-left">
                                                            <img class="user-photo" alt="" src="https://via.placeholder.com/150x150" data-demo-src="<?php echo e(asset('storage/'.$notif->event->image_event)); ?>"/>
                                                        </div>
                                                        <div class="user-content">
                                                            <p class="user-info"><span class="name"><?php echo e($notif->team->team_name); ?></span> <?php echo e($notif->message); ?></p>
                                                            <p class="time">
                                                                <time class="is-relative"><?php echo e($notif->created_at->diffForHumans()); ?></time>
                                                            </p>
                                                        </div>
                                                    </a>
                                                </li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php if(count($notification) == 0): ?>
                                                    <li>
                                                        <div class="user-content">
                                                            <p class="user-info">Tidak ada notifikasi</p>
                                                        </div>
                                                    </li>
                                                <?php endif; ?>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="datatable-toolbar">

                        <!-- <div class="field has-addons is-disabled">
                            <p class="control">
                                <button class="button h-button">
                                    <span class="icon is-small">
                                            <i class="fas fa-trash"></i>
                                        </span>
                                    <span>Hapus</span>
                                </button>
                            </p>
                        </div> -->

                        <div class="buttons">
                            <a href="<?php echo e(env('APP_URL')); ?>/su_admin/add_user" class="button h-button is-primary is-elevated">
                                <span class="icon">
                                        <i class="fas fa-plus"></i>
                                    </span>
                                <span>Tambah User</span>
                            </a>
                        </div>
                    </div>

                    <div class="page-content-inner">
                        <!-- Datatable -->
                        <div class="table-wrapper" data-simplebar>
                            <table id="users-datatable" class="table is-datatable is-hoverable table-is-bordered">
                                <thead>
                                    <tr>
                                        <th>
                                            <div class="control">
                                                <label class="checkbox is-primary is-outlined is-circle">
                                                    <input type="checkbox">
                                                    <span></span>
                                                </label>
                                            </div>
                                        </th>
                                        <th>Nama Lengkap</th>
                                        <th>Email</th>
                                        <th>Posisi</th>
                                        <th>Status</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <div class="control">
                                                <label class="checkbox is-circle is-primary is-outlined">
                                                    <input type="checkbox">
                                                    <span></span>
                                                </label>                 
                                            </div>
                                        </td>
                                        <td>
                                            <span class="has-dark-text dark-inverted is-font-alt is-weight-600 rem-90"><?php echo e($user->fullname); ?></span>
                                        </td>
                                        <td>
                                            <span class="has-dark-text dark-inverted is-font-alt is-weight-600 rem-90"><?php echo e($user->email); ?></span>
                                        </td>
                                        <td>
                                            <?php echo e($user->user_type); ?>

                                        </td>
                                        <td>
                                            <div class="status is-available">
                                                <i class="fas fa-circle"></i>
                                                <span>Aktif</span>
                                            </div>                    
                                        </td>
                                        <td>
                                            <button class="button is-danger is-rounded is-elevated" id="user_num_btn<?php echo e($user->id); ?>" onclick="initConfirm('Hapus pengguna', 'Apakah anda yakin? pengguna yang sudah di hapus tidak dapat di kembalikan', false, false, 'Hapus', 'Batal', function (closeEvent) {$('#user_num_<?php echo e($user->id); ?>').submit();})">
                                                <span class="icon">
                                                        <i data-feather="trash"></i>
                                                    </span>
                                                <span>Hapus</span>
                                            </button>
                                            <form action="<?php echo e(env('APP_URL')); ?>/su_admin/delete_user/<?php echo e($user->id); ?>" method="post" id="user_num_<?php echo e($user->id); ?>" class="is-hidden"><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?></form>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>

                        </div>

                        <div id="paging-first-datatable" class="pagination datatable-pagination">
                            <div class="datatable-info">
                                <span></span>
                            </div>
                        </div>

                    </div>

                </div>
            </div>

        </div>
    </div>
    <script src="<?php echo e(asset('public_/js/datatable.js')); ?>"></script>
    <?php if(session('notif')): ?>
        <script>
            $(document).ready(function () {
                notyf = new Notyf({
                    duration: 3000,
                    position: {
                    x: 'right',
                    y: 'bottom'
                    },
                    types: [{
                    type: 'green',
                    background: themeColors.green,
                    icon: {
                        className: 'fas fa-check',
                        tagName: 'i',
                        text: ''
                    }
                    }]
                }); 
                notyf.success("<?php echo e(session('notif')); ?>");
            });
        </script>
    <?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?><?php /**PATH C:\Users\FRENDY\Projects\Web Projects\Html Code\ifest-dash\resources\views/admin_/users/index.blade.php ENDPATH**/ ?>