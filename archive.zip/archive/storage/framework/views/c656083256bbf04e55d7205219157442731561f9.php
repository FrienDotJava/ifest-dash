<?php $__env->startSection('title', 'Dashboard'); ?>
<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.layouts.app','data' => []]); ?>
<?php $component->withName('layouts.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <form action="<?php echo e(route('logout')); ?>" method="post" class="is-hidden" id="logout"><?php echo csrf_field(); ?></form>
    <div id="ifst-app" class="app-wrapper">

        <div class="app-overlay"></div>
        <!-- Pageloader -->
        <div class="pageloader"></div>
        <div class="infraloader is-active"></div>
        <?php echo $__env->make('user_/slice_/sidehead', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- Content Wrapper -->
        <div class="view-wrapper" data-naver-offset="150" data-menu-item="#home-sidebar-menu" data-mobile-item="#home-sidebar-menu-mobile">

            <div class="page-content-wrapper">
                <div class="page-content is-relative">

                    <div class="page-title has-text-centered">

                        <div class="title-wrap">
                            <h1 class="title is-4">Dashboard</h1>
                        </div>

                        <div class="toolbar ml-auto">

                            <div class="toolbar-link">
                                <label class="dark-mode ml-auto">
                                    <input type="checkbox" checked>
                                    <span></span>
                                </label>
                            </div>
                        </div>
                    </div>

                    <div class="page-content-inner">

                        <!--Personal Dashboard V3-->
                        <div class="personal-dashboard personal-dashboard-v3">

                            <div class="columns">

                                <div class="column is-8">
                                    <div class="columns is-multiline is-flex-tablet-p">

                                        <div class="column is-6">
                                            <div class="dashboard-card is-welcome">
                                                <div class="welcome-title">
                                                    <h3 class="dark-inverted has-text-centered">Hello <?php echo e(Auth::user()->fullname); ?></h3>
                                                    <?php if($nullvalue != 0): ?>  
                                                    <p class="has-text-centered">
                                                    Sedikit lagi, kamu memiliki
                                                    <?php echo e($nullvalue); ?>

                                                    data yang harus dilengkapi sebelum mengikuti perlombaan.
                                                    </p>
                                                    <?php else: ?>
                                                    <p class="has-text-centered">
                                                        Data kamu sudah lengkap, silahkan mendaftarkan perlombaan yang ingin kamu ikuti.
                                                    </p>
                                                    <?php endif; ?>
                                                </div>
                                                <div class="welcome-progress is-flex" style="justify-content: center;">
                                                    <div id="welcome-gauge" class="gauge"></div>
                                                </div>
                                                <div class="button-wrap">
                                                    <?php if($nullvalue != 0): ?>
                                                        <a href="<?php echo e(env('APP_URL')); ?>/user/profil" class="button h-button is-primary is-fullwidth is-big is-raised">Lihat Profil</a>
                                                    <?php else: ?>
                                                        <a href="<?php echo e(env('APP_URL')); ?>/user/events  " class="button h-button is-primary is-fullwidth is-big is-raised">Daftar Kompetisi/Acara</a>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="column is-6">
                                            <h3 class="dark-inverted"><b>Lomba Yang Diikuti</b></h3>
                                            <div class="dashboard-card mt-2">
                                                <?php if(count($data_lomba)>0): ?>
                                                <?php $__currentLoopData = $data_lomba; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <a href="<?php echo e(env('APP_URL')); ?>/user/regis_event/<?php echo e($data->id_event); ?>/detail_tim" class="dashboard-card is-interview">
                                                        <div class="media-flex-center">
                                                            <div class="flex-meta">
                                                                <span><?php echo e($data->event->event_name); ?></span>
                                                                <span>
                                                                    <?php if($data->status == 1): ?>
                                                                        Terverifikasi
                                                                    <?php elseif($data->status == 0): ?>
                                                                        Belum Terverifikasi
                                                                    <?php else: ?>
                                                                        Tim Kamu Di Blacklist
                                                                    <?php endif; ?>
                                                                </span>
                                                            </div>
                                                            <div class="flex-end">
                                                                <i data-feather="chevron-right"></i>
                                                            </div>
                                                        </div>
                                                    </a>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php else: ?>
                                                    <div class="has-text-centered">
                                                        <p><?php echo e(__('Kamu tidak mengikuti lomba apapun.')); ?></p>
                                                    </div>
                                                <?php endif; ?>
                                            </div>

                                            <h3 class="dark-inverted is-6 mb-1"><b>Timeline</b></h3>
                                            <div class="list-widget list-widget-v3 is-straight">

                                                <div class="inner-list">
                                                    <div class="icon-timeline">
                                                        <?php
                                                            $rand_color = ['is-primary', 'is-info', 'is-success', 'is-orange', 'is-yellow']
                                                        ?>
                                                        <?php $__currentLoopData = $timeline; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <!--Timeline item-->
                                                        <div class="timeline-item">
                                                            <div class="timeline-icon is-squared <?php echo e($rand_color[rand(0,4)]); ?>">
                                                                <i data-feather="<?php echo e($item->icon); ?>"></i>
                                                            </div>
                                                            <div class="timeline-content">
                                                                <p><?php print_r($item->timeline) ?></p>
                                                                <span><?php echo e(\Carbon\Carbon::create($item->start)->format('d M Y')); ?> <?php if($item->close != null): ?> - <?php echo e(\Carbon\Carbon::create($item->close)->format('d M Y')); ?> <?php endif; ?><br> 
                                                                <?php if($item->close != null): ?>
                                                                    <?php if(now() >= $item->start && now() <= $item->close): ?>            
                                                                        ( Sedang Berlangsung )
                                                                    <?php endif; ?>
                                                                <?php elseif(Carbon\Carbon::now()->format('Y-m-d') == $item->start): ?>
                                                                    ( Sedang Berlangsung )
                                                                <?php endif; ?>
                                                                </span>
                                                            </div>
                                                        </div>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="column is-6 h-hidden-mobile h-hidden-tablet-p">
                                        </div>

                                    </div>
                                </div>

                                <div class="column is-4">
                                    <div class="widget picker-widget" style="height: 280px">
                                        <div class="widget-toolbar">
                                            <div class="left">
                                            </div>
                                            <div class="center">
                                                <h3 class="date"></h3>
                                            </div>
                                            <div class="right"></div>
                                        </div>
                                        <table class="calendar">

                                            <thead class="hari">

                                                <tr>

                                                    <td>Min</td>
                                                    <td>Sen</td>
                                                    <td>Sel</td>
                                                    <td>Rab</td>
                                                    <td>Kam</td>
                                                    <td>Jum</td>
                                                    <td>Sab</td>

                                                </tr>

                                            </thead>

                                            <tbody class="tanggal">

                                            </tbody>

                                        </table>
                                    </div>
                                    
                                </div>

                            </div>

                        </div>

                    </div>

                </div>
            </div>
        </div>
    </div>
    <!-- create hint css -->
    <script>
        $(document).ready(function(){
            generateCalendar(moment().month(), moment().year());
            getToday();
            var welcomeGauge = bb.generate({
                data: {
                columns: [["Profil", 100]],
                type: "gauge",
                onclick: function onclick(d, i) {
                    console.log("onclick", d, i);
                },
                onover: function onover(d, i) {
                    console.log("onover", d, i);
                },
                onout: function onout(d, i) {
                    console.log("onout", d, i);
                }
                },
                gauge: {
                label: {
                    extents: function extents() {
                    return "";
                    }
                }
                },
                color: {
                pattern: [themeColors.danger, themeColors.green],
                threshold: {
                    values: [70, 100]
                }
                },
                size: {
                height: 90,
                width: 90
                },
                padding: {
                bottom: 0
                },
                legend: {
                show: false,
                position: "inset"
                },
                bindto: "#welcome-gauge"
            });
            setTimeout(function () {
                welcomeGauge.load({
                columns: [["Profil", 0]]
                });
            }, 1000);
            setTimeout(function () {
                welcomeGauge.load({
                columns: [["Profil", "<?php echo e(round((100/count(Schema::getColumnListing('users'))) * (count(Schema::getColumnListing('users')) - $nullvalue), 0)); ?>"]]
                });
            }, 2000);
        })
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?><?php /**PATH C:\Users\FRENDY\Projects\Web Projects\Html Code\ifest-dash\resources\views/user_/dashboard.blade.php ENDPATH**/ ?>