<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.layouts.defaultlayout','data' => []]); ?>
<?php $component->withName('layouts.defaultlayout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div id="ifst-app" class="app-wrapper overflow-hidden">

        <!-- Pageloader -->
        <div class="pageloader is-full"></div>
        <div class="infraloader is-full is-active"></div>
        <div class="auth-wrapper">

            <div class="auth-wrapper-inner is-single">

                <!--Fake navigation-->
                <div class="auth-nav">
                    <div class="left"></div>
                    <div class="center mt-3">
                        <a href="/" class="header-item mt-5">
                            <img class="light-image" src="<?php echo e(asset('images/ifest.png')); ?>" alt="">
                            <img class="dark-image" src="<?php echo e(asset('images/ifest.png')); ?>" alt="">
                        </a>
                    </div>
                    <div class="right">
                        <label class="dark-mode ml-auto">
                            <input type="checkbox" checked>
                            <span></span>
                        </label>
                    </div>
                </div>

                <!--Single Centered Form-->
                <div class="single-form-wrap">

                    <div class="inner-wrap">
                        <!--Form Title-->
                        <div class="auth-head">
                            <h2>Informatics Festival #12</h2>
                            <p>Silahkan masuk ke akun anda</p>
                            <a href="daftar">Saya tidak punya akun</a>
                        </div>

                        <!--Form-->
                        <div class="form-card">
                            <?php if($errors->any()): ?>
                                <div class="has-text-centered danger-text mb-2"><?php echo e(implode('', $errors->all(':message'))); ?></div>
                            <?php endif; ?>
                            <form method="POST" action="<?php echo e(route('masuk')); ?>">
                                <?php echo csrf_field(); ?>
                                <div id="signin-form" class="login-form">
                                    <!-- Input -->
                                    <div class="field">
                                        <div class="control has-icon">
                                            <input id="email" type="email" class="input <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus placeholder="Email">
                                            <span class="form-icon">
                                                    <i data-feather="mail"></i>
                                                </span>
                                        </div>
                                        <div id="email_result"></div>
                                    </div>
                                    <!-- Input -->
                                    <div class="field">
                                        <div class="control has-icon">
                                            <input id="password" type="password" class="input <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="current-password" placeholder="Password">
                                            <span class="form-icon">
                                                    <i data-feather="lock"></i>
                                                </span>
                                        </div>
                                        <div id="password_result"></div>
                                    </div>

                                    <div class="setting-item">
                                        <label class="form-switch is-primary">
                                            <input type="checkbox" class="is-switch" name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?> id="busy-mode-toggle">
                                            <i></i>
                                        </label>
                                        <div class="setting-meta">
                                            <span>Remember Me</span>
                                        </div>
                                    </div>

                                    <!-- Submit -->
                                    <div class="control login">
                                        <button id="login_ifst" class="button h-button is-primary is-bold is-fullwidth is-raised">Login</button>
                                    </div>


                                </div>
                            </form>
                        </div>

                        <div class="forgot-link has-text-centered">
                            <a href="lupa-password">Lupa Password?</a>
                        </div>
                        <div class="forgot-link has-text-centered">
                            <a href="daftar">Belum punya akun?</a>
                        </div>

                    </div>

                </div>

            </div>
        </div>
    </div>
    <script>
        // Validation
        $(document).ready(function() {
        $('#email').keyup(function () {
            var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
            if (re.test($(this).val())) {
                $("#email_result").text("Format email Benar!");
                $("#email_result").removeClass();$("#email_result").addClass("success-text");
                $('#password').keyup(function () {
                    if($(this).val() !== ""){
                        $("#login_ifst").prop("disabled", false);
                    }
                });
            } else {
                $("#email_result").text("Format email Salah!");
                $("#email_result").removeClass();$("#email_result").addClass("danger-text");
                $("#login_ifst").prop("disabled", true);
            }
        });
        if($("#email").val() == "" && $("#password").val() == ""){
            $("#login_ifst").prop("disabled", true);
        }

        const password = document.querySelector('#password');
        password.addEventListener('keyup', function(e){
            if (e.getModifierState('CapsLock')) {
                $('#password_result').addClass('danger-text');
                $('#password_result').text('Caps lock is on');
            } else {
                $('#password_result').text('');
            }
        })

        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?><?php /**PATH C:\Users\FRENDY\Projects\Web Projects\Html Code\ifest-dash\resources\views/auth/login.blade.php ENDPATH**/ ?>