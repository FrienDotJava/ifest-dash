<?php $__env->startSection('title', 'MUC'); ?>
<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.layouts.app','data' => []]); ?>
<?php $component->withName('layouts.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <form action="<?php echo e(route('logout')); ?>" method="post" class="is-hidden" id="logout"><?php echo csrf_field(); ?></form>
    <div id="ifst-app" class="app-wrapper">

        <div class="app-overlay"></div>
        <!-- Pageloader -->
        <div class="pageloader"></div>
        <div class="infraloader is-active"></div>
        <?php echo $__env->make('admin_/slice_/sidehead', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="view-wrapper" data-naver-offset="342" data-menu-item="#hck-sidebar-menu" data-mobile-item="#hck-sidebar-menu-mobile">

            <div class="page-content-wrapper">
                <div class="page-content is-relative">

                    <div class="page-title has-text-centered">

                        <div class="title-wrap">
                            <h1 class="title is-4">Mobile UI/UX Competition (MUC)</h1>
                        </div>

                        <div class="toolbar ml-auto">

                            <div class="toolbar-link">
                                <label class="dark-mode ml-auto">
                                    <input type="checkbox" checked>
                                    <span></span>
                                </label>
                            </div>

                            <?php if(Auth::user()->user_type == 'superuser'): ?>
                            <a class="toolbar-link right-panel-trigger" data-panel="activity-panel">
                                <i data-feather="grid"></i>
                            </a>
                            <?php endif; ?>

                            <div class="toolbar-notifications is-hidden-mobile">
                                <div class="dropdown is-spaced is-dots is-right dropdown-trigger">
                                    <div class="is-trigger" aria-haspopup="true">
                                        <i data-feather="bell"></i>
                                        <?php if(count($notification) > 0): ?>
                                        <span class="new-indicator pulsate"></span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="dropdown-menu" role="menu">
                                        <div class="dropdown-content">
                                            <div class="heading">
                                                <div class="heading-left">
                                                    <h6 class="heading-title">Notifikasi</h6>
                                                </div>
                                                <!-- <div class="heading-right">
                                                    <a class="notification-link" href="admin-profile-notifications.html">See all</a>
                                                </div> -->
                                            </div>
                                            <ul class="notification-list">
                                                <?php $__currentLoopData = $notification; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notif): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li>
                                                    <a class="notification-item" href="<?php echo e(env('APP_URL')); ?>/su_admin/<?php echo e($notif->id_event); ?>/team/<?php echo e($notif->id_team); ?>">
                                                        <div class="img-left">
                                                            <img class="user-photo" alt="" src="https://via.placeholder.com/150x150" data-demo-src="<?php echo e(asset('storage/'.$notif->event->image_event)); ?>"/>
                                                        </div>
                                                        <div class="user-content">
                                                            <p class="user-info"><span class="name"><?php echo e($notif->team->team_name); ?></span> <?php echo e($notif->message); ?></p>
                                                            <p class="time">
                                                                <time class="is-relative"><?php echo e($notif->created_at->diffForHumans()); ?></time>
                                                            </p>
                                                        </div>
                                                    </a>
                                                </li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php if(count($notification) == 0): ?>
                                                    <li>
                                                        <div class="user-content">
                                                            <p class="user-info">Tidak ada notifikasi</p>
                                                        </div>
                                                    </li>
                                                <?php endif; ?>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="user-grid-toolbar">
                        <div class="buttons">
                            <div class="field">
                                <div class="control">
                                    <div class="h-select">
                                        <div class="select-box">
                                            <span>
                                                <?php if(isset($filter)): ?>
                                                    <?php if($filter == '1'): ?>
                                                        Terverifikasi
                                                    <?php elseif($filter == '0'): ?>
                                                        Belum Terverifikasi
                                                    <?php elseif($filter == 'bl'): ?>
                                                        Blacklist/Mengundurkan diri
                                                    <?php endif; ?>
                                                <?php else: ?>
                                                    Semua
                                                <?php endif; ?>
                                            </span>
                                        </div>
                                        <div class="select-icon">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-down"><polyline points="6 9 12 15 18 9"></polyline></svg>
                                        </div>
                                        <div class="select-drop has-slimscroll-sm">
                                            <div class="drop-inner">
                                                <div class="option-row">
                                                    <form action="<?php echo e(env('APP_URL')); ?>/su_admin/muc" id="semua_team" method="get"></form>
                                                    <input type="radio" onclick="$('#semua_team').submit()" name="grid_filter">
                                                    <div class="option-meta">
                                                        <span>Semua</span>
                                                    </div>
                                                </div>
                                                <div class="option-row">
                                                    <form action="<?php echo e(env('APP_URL')); ?>/su_admin/muc/1" id="verif_team" method="get"></form>
                                                    <input type="radio" onclick="$('#verif_team').submit()" name="grid_filter">
                                                    <div class="option-meta">
                                                        <span>Terverifikasi</span>
                                                    </div>
                                                </div>
                                                <div class="option-row">
                                                    <form action="<?php echo e(env('APP_URL')); ?>/su_admin/muc/0" id="nonverif_team" method="get"></form>
                                                    <input type="radio" onclick="$('#nonverif_team').submit()" name="grid_filter">
                                                    <div class="option-meta">
                                                        <span>Belum Terverifikasi</span>
                                                    </div>
                                                </div>
                                                <div class="option-row">
                                                    <form action="<?php echo e(env('APP_URL')); ?>/su_admin/muc/bl" id="bl_team" method="get"></form>
                                                    <input type="radio" onclick="$('#bl_team').submit()" name="grid_filter">
                                                    <div class="option-meta">
                                                        <span>Blacklist/Mengundurkan diri</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="page-content-inner">
                        <div class="user-grid user-grid-v2">

                            <!--List Empty Search Placeholder -->
                            <div class="page-placeholder custom-text-filter-placeholder is-hidden">
                                <div class="placeholder-content">
                                    <h3>Kami tidak dapat menemukan hasil yang cocok.</h3>
                                    <p class="is-larger">Sepertinya kami tidak dapat menemukan hasil yang cocok untuk
                                         istilah pencarian yang Anda masukkan. Silakan coba istilah atau kriteria pencarian yang berbeda .</p>
                                </div>
                            </div>

                            <div class="columns is-multiline">

                                <!--Grid item-->
                                <?php if(count($team_event) > 0): ?>
                                    <?php $__currentLoopData = $team_event; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="column is-3">
                                            <div class="grid-item-wrap">
                                                <div class="grid-item-head">
                                                    <div class="flex-head">
                                                        <div class="meta">
                                                            <span class="dark-inverted">
                                                                <?php
                                                                    $task_count = 0;
                                                                    $alltask = count($task_event);
                                                                ?>
                                                                <?php $__currentLoopData = $task_team; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php if($task->team_id == $team->team_id): ?>
                                                                        <?php
                                                                            $task_count += 1;
                                                                        ?>
                                                                    <?php endif; ?>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                <?php if($team->status == 1): ?>
                                                                    Terverifikasi
                                                                <?php elseif($team->status == 0): ?>
                                                                    <?php if($task_count == $count_task): ?>
                                                                        Menunggu Verifikasi
                                                                    <?php else: ?>
                                                                        Belum Terverifikasi
                                                                    <?php endif; ?>
                                                                <?php else: ?>
                                                                    Mengundurkan Diri/Blacklist
                                                                <?php endif; ?>
                                                            </span>
                                                            <span><?php echo e($alltask - $task_count); ?> Task Tersisa</span>
                                                        </div>
                                                        <div class="status-icon 
                                                            <?php if($team->status == 1): ?>
                                                                is-success
                                                            <?php elseif($team->status == 0): ?>
                                                                is-warning
                                                            <?php else: ?>
                                                                is-danger
                                                            <?php endif; ?>
                                                        ">
                                                            <i class="
                                                            <?php if($team->status == 1): ?>
                                                                fas fa-check
                                                            <?php elseif($team->status == 0): ?>
                                                                fas fa-spinner
                                                            <?php else: ?>
                                                                fas fa-times
                                                            <?php endif; ?>"></i>
                                                        </div>
                                                    </div>
                                                    <div class="buttons">
                                                        <a href="<?php echo e(env('APP_URL')); ?>/su_admin/muc/team/<?php echo e($team->team_id); ?>#task-tab" class="button h-button is-dark-outlined" style="width: 100%;">
                                                            <span class="icon">
                                                                    <i data-feather="check-circle"></i>
                                                                </span>
                                                            <span>Tasks</span>
                                                        </a>
                                                    </div>
                                                </div>
                                                <div class="grid-item">
                                                    <h3 class="dark-inverted" data-filter-match><?php echo e($team->team_name); ?></h3>
                                                    <p data-filter-match><?php echo e($team->owner->fullname); ?></p>
                                                    <div class="buttons mt-2">
                                                        <a href="<?php echo e(env('APP_URL')); ?>/su_admin/muc/team/<?php echo e($team->team_id); ?>" class="button h-button is-dark-outlined">
                                                            <span>Lihat Data</span>
                                                        </a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <div class="page-placeholder custom-text-filter-placeholder">
                                        <div class="placeholder-content">
                                            <h3>Data tidak tersedia.</h3>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <?php echo e($team_event->links('vendor.pagination.tailwind')); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?><?php /**PATH C:\Users\FRENDY\Projects\Web Projects\Html Code\ifest-dash\resources\views/admin_/muc/index.blade.php ENDPATH**/ ?>