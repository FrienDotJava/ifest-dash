<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <title><?php echo $__env->yieldContent('title'); ?> - <?php echo e(config('app.name', 'Informatics Festival #12')); ?></title>
        <link rel="stylesheet" href="<?php echo e(asset('public_/css/app.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('public_/css/main.css')); ?>">
        <link rel="shortcut icon" href="<?php echo e(asset('images/ifest.png')); ?>" type="image/x-icon">
        <!-- Scripts -->
        <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
        <script src="<?php echo e(asset('public_/js/app.js')); ?>"></script>
        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@500;600;700;800;900&amp;display=swap" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,600,700" rel="stylesheet">
    </head>
    <body>
        <?php echo e($slot); ?>

        <script src="<?php echo e(asset('public_/js/functions.js')); ?>"></script>
        <script src="<?php echo e(asset('public_/js/main.js')); ?>"></script>
    </body>
</html>
<?php /**PATH C:\Users\FRENDY\Projects\Web Projects\Html Code\ifest-dash\resources\views/components/layouts/app.blade.php ENDPATH**/ ?>