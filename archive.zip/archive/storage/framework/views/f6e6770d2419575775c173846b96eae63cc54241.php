<?php $__env->startSection('title', 'Dashboard'); ?>
<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.layouts.app','data' => []]); ?>
<?php $component->withName('layouts.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <form action="<?php echo e(route('logout')); ?>" method="post" class="is-hidden" id="logout"><?php echo csrf_field(); ?></form>
    <div id="ifst-app" class="app-wrapper">

        <div class="app-overlay"></div>
        <!-- Pageloader -->
        <div class="pageloader"></div>
        <div class="infraloader is-active"></div>
        <?php echo $__env->make('admin_/slice_/sidehead', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- Content Wrapper -->
        <div class="view-wrapper" data-naver-offset="150" data-menu-item="#home-sidebar-menu" data-mobile-item="#home-sidebar-menu-mobile">

            <div class="page-content-wrapper">
                <div class="page-content is-relative">

                    <div class="page-title has-text-centered">

                        <div class="title-wrap">
                            <h1 class="title is-4">Dashboard</h1>
                        </div>

                        <div class="toolbar ml-auto">

                            <div class="toolbar-link">
                                <label class="dark-mode ml-auto">
                                    <input type="checkbox" checked>
                                    <span></span>
                                </label>
                            </div>
                            <?php if(Auth::user()->user_type == 'superuser'): ?>
                            <a class="toolbar-link right-panel-trigger" data-panel="activity-panel">
                                <i data-feather="grid"></i>
                            </a>
                            <?php endif; ?>
                            <div class="toolbar-notifications is-hidden-mobile">
                                <div class="dropdown is-spaced is-dots is-right dropdown-trigger">
                                    <div class="is-trigger" aria-haspopup="true">
                                        <i data-feather="bell"></i>
                                        <?php if(count($notification) > 0): ?>
                                        <span class="new-indicator pulsate"></span>
                                        <?php endif; ?>
                                    </div>
                                    <div class="dropdown-menu" role="menu">
                                        <div class="dropdown-content">
                                            <div class="heading">
                                                <div class="heading-left">
                                                    <h6 class="heading-title">Notifikasi</h6>
                                                </div>
                                                <!-- <div class="heading-right">
                                                    <a class="notification-link" href="admin-profile-notifications.html">See all</a>
                                                </div> -->
                                            </div>
                                            <ul class="notification-list">
                                                <?php $__currentLoopData = $notification; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notif): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li>
                                                    <a class="notification-item" href="<?php echo e(env('APP_URL')); ?>/su_admin/<?php echo e($notif->id_event); ?>/team/<?php echo e($notif->id_team); ?>">
                                                        <div class="img-left">
                                                            <img class="user-photo" alt="" src="https://via.placeholder.com/150x150" data-demo-src="<?php echo e(asset('storage/'.$notif->event->image_event)); ?>"/>
                                                        </div>
                                                        <div class="user-content">
                                                            <p class="user-info"><span class="name"><?php echo e($notif->team->team_name); ?></span> <?php echo e($notif->message); ?></p>
                                                            <p class="time">
                                                                <time class="is-relative"><?php echo e($notif->created_at->diffForHumans()); ?></time>
                                                            </p>
                                                        </div>
                                                    </a>
                                                </li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php if(count($notification) == 0): ?>
                                                    <li>
                                                        <div class="user-content">
                                                            <p class="user-info">Tidak ada notifikasi</p>
                                                        </div>
                                                    </li>
                                                <?php endif; ?>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="page-content-inner">

                        <!--Personal Dashboard V3-->
                        <div class="personal-dashboard personal-dashboard-v3">

                            <div class="columns row">

                                <div class="column is-8">
                                    <div class="columns is-multiline is-flex-tablet-p">

                                        <div class="column is-6">
                                            <div class="dashboard-card is-welcome">
                                                <div class="welcome-title">
                                                    <h3 class="dark-inverted has-text-centered">Hello <?php echo e(Auth::user()->fullname); ?></h3>
                                                    <p class="has-text-centered">
                                                        <?php if(Auth::user()->user_type == 'staff'): ?>
                                                            <?php if($not_verified > 0): ?>
                                                                <?php echo e(__('Kamu memiliki '.$not_verified.' data yang belum diverifikasi.')); ?> <a href="#">Lihat dan verifikasi data dengan cara klik pada salah satu kompetisi/acara</a>
                                                            <?php endif; ?>
                                                        <?php endif; ?>
                                                    </p>
                                                </div>
                                            </div>
                                            <div class="left">
                                                <span class="dark-inverted title is-6">Pendaftaran Terbaru</span>
                                                <span><a class="is-dark-primary"></a></span>
                                            </div>
                                            <div class="dashboard-card mt-2">
                                                <?php if(count($nw_pdft) > 0): ?>
                                                <?php $__currentLoopData = $nw_pdft; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pdf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <a href="<?php echo e(env('APP_URL')); ?>/su_admin/<?php echo e($pdf->id_event); ?>/team/<?php echo e($pdf->team_id); ?>" class="dashboard-card is-interview">
                                                        <div class="media-flex-center">
                                                            <div class="flex-meta">
                                                                <span><?php echo e($pdf->team_name . ' - ' . $pdf->event->event_name); ?></span>
                                                                <span><?php echo e($pdf->created_at); ?>

                                                                    <?php
                                                                        $count = 0;
                                                                        foreach($detail_task as $dt){
                                                                            if($dt->event_id == $pdf->id_event && $dt->condition_task == NULL){
                                                                                $count++;
                                                                            }
                                                                        }
                                                                    ?>
                                                                    <?php if($pdf->task->count() == $count): ?>
                                                                        <span class="tag is-light">
                                                                            Menunggu Verifikasi
                                                                        </span>
                                                                    <?php endif; ?>
                                                                </span>
                                                            </div>
                                                            <div class="flex-end">
                                                                <i data-feather="chevron-right"></i>
                                                            </div>
                                                        </div>
                                                    </a>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php else: ?>
                                                    <p class="has-text-centered">
                                                        Tidak tersedia
                                                    </p>
                                                <?php endif; ?>
                                            </div>
                                        </div>

                                        <div class="column is-6">
                                            <div class="stats-wrapper">
                                                <div class="left">
                                                    <span class="dark-inverted title is-6">Jumlah Peserta</span>
                                                    <span><a class="is-dark-primary"></a></span>
                                                </div>
                                                <div class="columns is-multiline is-flex-tablet-p">
                                                    <div class="column is-6">
                                                        <a href="<?php echo e(env('APP_URL')); ?>/su_admin/i2c" class="dashboard-card">
                                                            <div class="media-flex-center">
                                                                <div class="h-icon is-info is-rounded">
                                                                    <i data-feather="user"></i>
                                                                </div>
                                                                <div class="flex-meta">
                                                                    <span><?php echo e($i2c); ?></span>
                                                                    <span>I2C</span>
                                                                </div>
                                                            </div>
                                                        </a>
                                                    </div>
                                                    <div class="column is-6">
                                                        <a href="<?php echo e(env('APP_URL')); ?>/su_admin/wdc" class="dashboard-card">
                                                            <div class="media-flex-center">
                                                                <div class="h-icon is-purple is-rounded">
                                                                    <i data-feather="user"></i>
                                                                </div>
                                                                <div class="flex-meta">
                                                                        <span><?php echo e($wdc); ?></span>
                                                                        <span>WDC</span>
                                                                </div>
                                                            </div>
                                                        </a>
                                                    </div>
                                                    <div class="column is-12">
                                                        <a href="<?php echo e(env('APP_URL')); ?>/su_admin/muc" class="dashboard-card">
                                                            <div class="media-flex-center">
                                                                <div class="h-icon is-green is-rounded">
                                                                    <i data-feather="user"></i>
                                                                </div>
                                                                <div class="flex-meta">
                                                                    <span><?php echo e($muc); ?></span>
                                                                    <span>MUC</span>
                                                                </div>
                                                            </div>
                                                        </a>
                                                    </div>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="column is-4"> 
                                    
                                    <div class="left">
                                        <span class="dark-inverted title is-6">Timeline</span>
                                        <span><a class="is-dark-primary"></a></span>
                                    </div>
                                    <div class="list-widget list-widget-v3 is-straight">

                                        <div class="inner-list">
                                            <div class="icon-timeline">
                                                <?php
                                                    $rand_color = ['is-primary', 'is-info', 'is-success', 'is-orange', 'is-yellow']
                                                ?>
                                                <?php $__currentLoopData = $timeline; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="timeline-item">
                                                    <div class="timeline-icon is-squared <?php echo e($rand_color[array_rand($rand_color)]); ?>">
                                                        <i data-feather="<?php echo e($item->icon); ?>"></i>
                                                    </div>
                                                    <div class="timeline-content">
                                                        <p><?php print_r($item->timeline) ?></p>
                                                        <span><?php echo e(\Carbon\Carbon::create($item->start)->format('d M Y')); ?> <?php if($item->close != null): ?> - <?php echo e(\Carbon\Carbon::create($item->close)->format('d M Y')); ?> <?php endif; ?><br> 
                                                        <?php if($item->close != null): ?>
                                                            <?php if(now() >= $item->start && now() <= $item->close): ?>
                                                                ( Sedang Berlangsung )
                                                            <?php endif; ?>
                                                        <?php elseif(Carbon\Carbon::now()->format('Y-m-d') == $item->start): ?>
                                                            ( Sedang Berlangsung )
                                                        <?php endif; ?>
                                                        </span>
                                                    </div>
                                                </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                        </div>
                                    </div>  
                                </div>

                            </div>

                        </div>

                    </div>

                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?><?php /**PATH C:\Users\FRENDY\Projects\Web Projects\Html Code\ifest-dash\resources\views/admin_/dashboard.blade.php ENDPATH**/ ?>