// <?php 
// $targetFolder = $_SERVER['DOCUMENT_ROOT'].'/dash/storage/app/public';
// $linkFolder = $_SERVER['DOCUMENT_ROOT'].'/dash/public/storage';
// symlink($targetFolder,$linkFolder);
// ?>